import java.lang.*;

public class Main {

    public static void main(String[] args) {
        Pythagorean id = new Pythagorean();
        double c = id.calculateHypotenuse(4,4);
        System.out.println(c);
    }
}


