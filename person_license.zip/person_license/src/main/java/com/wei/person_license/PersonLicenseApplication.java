package com.wei.person_license;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonLicenseApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonLicenseApplication.class, args);
	}
}
