package com.wei.web.models;

public interface pet {
    public String showAffection();
}
