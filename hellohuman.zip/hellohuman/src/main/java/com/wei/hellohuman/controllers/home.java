package com.wei.hellohuman.controllers;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class home {
    @RequestMapping("/")
    public String index(@RequestParam(value = "name", required = false) String searchQuery, Model model){
        model.addAllAttributes("name",searchQuery);
        return "index";
    }
}
