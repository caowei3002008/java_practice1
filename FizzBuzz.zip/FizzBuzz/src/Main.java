public class Main {

    public static void main(String[] args) {
        FizzBuzz id = new FizzBuzz();
        String result = id.fizzBuzz(1);
        System.out.println(result);
    }
}
