import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        basicMethod basic = new basicMethod();
//        basic.printOneTo();
//        basic.printOneOdd();
//        basic.sum();
        int[] a = {1,3,5,7,9,13,-9,-8,-7,-6};
//        basic.arrayDisply(a);
//        basic.findMax(a);
//        basic.addOddNumber();
//        System.out.println(basic.getAverage(a));
//        System.out.println(basic.getGreaterThanY(3,a));
//        System.out.println(Arrays.toString(basic.square(a)));
//        System.out.println(Arrays.toString(basic.eliminateNegativeNumber(a)));
//        System.out.println(Arrays.toString(basic.maxMinAver(a)));
        System.out.println(Arrays.toString(basic.shiftArray(a)));



    }
}
