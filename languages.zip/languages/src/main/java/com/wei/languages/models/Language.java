package com.wei.languages.models;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Language {

    @Size(min = 2,max = 30, message="Name must be between 2 and 20 character")
    private String name;

    @Size(min = 2,max = 30, message="Name must be between 2 and 20 character")
    private String creator;

    @Size(min = 2,max = 30, message="Name must be between 2 and 20 character")
    private String version;

    public Language(){

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getversion() {
        return version;
    }

    public void setversion(String version) {
        this.version = version;
    }

    public Language(String name, String creator, String version) {
        this.name = name;
        this.creator = creator;
        this.version = version;
    }
}
