package com.wei.languages.controllers;


import com.wei.languages.models.Language;
import com.wei.languages.services.LanguageService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Controller
public class Languages {
    private final LanguageService languageService;

    public Languages(LanguageService languageService){
        this.languageService = languageService;
    }

    @RequestMapping("/languages")
    public String languages(@ModelAttribute("language") Language language, Model model){
        model.addAttribute("Languages",languageService.allLanguages() );
        for(Language item : languageService.allLanguages()){
            System.out.println(item.getName());
            System.out.println(item.getversion());
            System.out.println(item.getCreator());
        }
        System.out.println(languageService.allLanguages());
        return "index";
    }

    @RequestMapping(path = "/add", method = RequestMethod.POST)
    public String  allLanguage(@Valid @ModelAttribute("language") Language language, BindingResult result){
        if(result.hasErrors()){
            return "index";
        }else{
            languageService.addLanguage(language);
            return "redirect:/languages";
        }
    }

    @RequestMapping("/languages/{index}/")
    public String show(@PathVariable("index") int index, Model model){
        model.addAttribute("language",languageService.findLanguageByIndex(index));
        model.addAttribute("id",index);
        return "show";
    }

    @RequestMapping("/delete/{id}/")
    public String delete(@PathVariable("id") int id){
        languageService.destroyLanguage(id);
        return "redirect:/languages";
    }

    @RequestMapping("/update/{id}/")
    public String update(@ModelAttribute("language") Language language, @PathVariable("id") int id, Model model){
        model.addAttribute("ll",languageService.findLanguageByIndex(id));
        model.addAttribute("id",id);
        return "edit";
    }

    @PostMapping("/languages/update/{id}")
    public String updateLanguage(@Valid @ModelAttribute("language") Language language, BindingResult result, @PathVariable("id") int id) {
        if (result.hasErrors()) {
            return "edit";
        }else{
            languageService.updateLanguage(id, language);
            return "redirect:/languages";
        }
    }

}
