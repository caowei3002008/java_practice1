package com.wei.languages.services;

import com.wei.languages.models.Language;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class LanguageService {

    private List<Language> languages = new ArrayList<Language>();

    public List<Language> allLanguages(){
        return languages;
    }

    public Language findLanguageByIndex(int index){
        if(index < languages.size()){
            return languages.get(index);
        }else{
            return null;
        }
    }

    public Language updateLanguage(int id, Language language){
        if(id < languages.size()){
            return languages.set(id, language);
        }else{
            return null;
        }
    }

    public void destroyLanguage(int id){
        if(id< languages.size()){
            languages.remove(id);
        }
    }

    public void addLanguage(Language language){
        languages.add(language);
    }

}
